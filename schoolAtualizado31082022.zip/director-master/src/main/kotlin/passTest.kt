//fun passTest() {
//    if (missingNumber > 30) {
//        return println("Reprovação por falta")
//    }
//    else if (averageGrade < 6.0){
//        println("reprovado por nota")
//    }
//    else if (numeroDeTrabalhos < 2){
//        println("reprovado por não fazer trabalhos")
//    }
//    else {
//        println("aprovado")
//    }
//
//}