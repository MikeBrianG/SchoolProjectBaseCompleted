fun main () {
    println("Bem vindo ao sistema escolar")

    open class Students(
        val name: String,
        val registration: Int,
        val grade: String,
        val averageGrade: Double,
        val missingNumber: Int,
        val numeroDeTrabalhos: Int
    ) {
        open fun passTest() {
            if (missingNumber > 30) {
                return println("Reprovação por falta")
            }
            else if (averageGrade < 6.0){
                println("reprovado por nota")
            }
            else if (numeroDeTrabalhos < 2){
                println("reprovado por não fazer trabalhos")
            }
            else {
                println("aprovado")
            }

        }


        fun avarageGradeTest(args: Array<String>) {
            val mediaStudents = doubleArrayOf(5.0, 6.0, 8.0)
            var soma = 0.0

            for (notes in mediaStudents) {
                soma += notes

            }
        }
    }


    val brenis = Students (
        name = "Brenis",
        registration = 1000,
        grade = "4 Série",
        averageGrade = 7.7,
        missingNumber = 28,
        numeroDeTrabalhos = 2
    )


    println("${brenis.name}")
    println("${brenis.registration}")
    println("${brenis.grade}")
    println("${brenis.averageGrade}")
    println("${brenis.missingNumber}")
    println("${brenis.numeroDeTrabalhos}")
    println("${brenis.passTest()}")

    val Roberto = Director(
        name = "Roberto",
        cpf = "1010",
        wage = 2000.0
    )
    println(Roberto.name)
    println(Roberto.cpf)
    println(Roberto.wage)
    println(Roberto.bonus())
}













    




